# BIBI Neon Racing → Android APK (Capacitor)

Усе вже підготовлено: оптимізована гра лежить у `www/` (музика — окремим файлом `www/audio/tesla.mp3`).
APK збирається двома шляхами — виберіть зручніший.

## Шлях A. Збірка на своєму ПК (Android Studio)

Потрібно один раз встановити: **Node.js 22 LTS**, **Android Studio** (разом із Android SDK), **JDK 21** (іде в комплекті Android Studio).

```bash
cd bibi-android
npm install                       # ставить Capacitor
node scripts/prepare-android.js   # створює папку android/ + налаштовує маніфест, MainActivity, тему, іконки
npx cap sync android              # копіює www/ у Android-проєкт
npx cap open android              # відкриває Android Studio
```

В Android Studio: дочекайтесь Gradle Sync → меню **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
Готовий файл: `android/app/build/outputs/apk/debug/app-debug.apk` — перекиньте на телефон і встановіть
(дозвольте «Встановлення з невідомих джерел»).

Без Android Studio (тільки консоль, якщо SDK встановлено і заданий ANDROID_HOME):
```bash
cd android
./gradlew assembleDebug        # Windows: gradlew.bat assembleDebug
```

Після будь-якої зміни гри в `www/index.html`: `npx cap sync android` і знову Build.

## Шлях B. Без встановлення нічого — GitHub Actions

1. Створіть порожній репозиторій на GitHub і залийте туди вміст цієї папки (разом із `.github/`).
2. Вкладка **Actions → Build Android APK → Run workflow**.
3. Через 3–6 хв у запуску з'явиться артефакт `bibi-neon-racing-debug-apk` — це `app-debug.apk`.

## Release-APK (для публікації)

```bash
keytool -genkey -v -keystore bibi.keystore -alias bibi -keyalg RSA -keysize 2048 -validity 10000
```
У Android Studio: **Build → Generate Signed Bundle / APK → APK**, оберіть `bibi.keystore`.
Для Google Play краще `.aab` (Android App Bundle) — той самий пункт меню. Файл `.keystore` не губіть і не публікуйте.

## Що налаштовано автоматично (`scripts/prepare-android.js`)

| Вимога | Як зроблено |
|---|---|
| Landscape | `android:screenOrientation="sensorLandscape"` в AndroidManifest |
| Повний екран (Immersive) | `MainActivity.java`: ховає status/navigation bar, повертається після свайпу |
| Екран не гасне | `FLAG_KEEP_SCREEN_ON` + дозвіл `WAKE_LOCK` |
| Апаратне прискорення | `android:hardwareAccelerated="true"` + `LAYER_TYPE_HARDWARE` для WebView, `largeHeap` |
| Вирізи камери | `windowLayoutInDisplayCutoutMode=shortEdges` + `viewport-fit=cover` + CSS `env(safe-area-inset-*)` |
| Автоплей звуку | `setMediaPlaybackRequiresUserGesture(false)` + розблокування першим тапом у самій грі |
| Без зуму/скролу | `user-scalable=no`, `touch-action`, блокування pinch/double-tap, `overscroll-behavior:none` |

## Що оптимізовано в самій грі

* **Авто-якість (⚙️ у грі):** при старті визначається потужність телефону (RAM/ядра). Під час гонки міряється FPS —
  якщо менше ~40, графіка автоматично знижується (4 рівні: Висока → Середня → Низька → Мінімальна):
  менший `devicePixelRatio`/розмір canvas, вимкнені blur/тіні/фільтри CSS, на «Мінімальній» — 3D-дорога вимикається
  і FPS обмежується 30. Кнопка ⚙️ вгорі гри перемикає рівень вручну (запам'ятовується).
* **Game loop:** `requestAnimationFrame` + delta-time (стабільна швидкість на 60/90/120 Гц), ліміт FPS на слабких.
* **GC:** повторне використання матриць у 3D-рушії (без `new Float32Array` на кожен об'єкт кадру), ліміти частинок.
* **Рендер:** `will-change`/`translateZ(0)` для canvas, спрощені ефекти на слабких рівнях.
* **Звук:** музика — окремий mp3-файл (а не 5 МБ base64 у пам'яті), `AudioContext.suspend()` у фоні, відновлення після повернення.
* **Тач:** `touch-action`, без затримки кліку, без зуму/виділення тексту.

## Тест на реальних пристроях

Підключіть телефон (USB-налагодження) → в Android Studio **Run ▶**. Для налагодження WebView:
у `capacitor.config.json` поставте `"webContentsDebuggingEnabled": true` → у Chrome на ПК відкрийте `chrome://inspect`.
