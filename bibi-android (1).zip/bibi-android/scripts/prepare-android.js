// Створює Android-платформу (якщо її ще нема) і налаштовує маніфест, MainActivity, тему.
// Запуск:  node scripts/prepare-android.js
const fs = require("fs"), path = require("path"), cp = require("child_process");
const root = path.resolve(__dirname, "..");
const run = (c) => cp.execSync(c, { cwd: root, stdio: "inherit" });
const cfg = JSON.parse(fs.readFileSync(path.join(root, "capacitor.config.json"), "utf8"));
const appId = cfg.appId;

if (!fs.existsSync(path.join(root, "android"))) {
  console.log("→ cap add android");
  run("npx cap add android");
}

// 1) AndroidManifest.xml
const manPath = path.join(root, "android/app/src/main/AndroidManifest.xml");
let man = fs.readFileSync(manPath, "utf8");
if (!man.includes("sensorLandscape")) {
  man = man.replace(/<application/, '<application\n        android:hardwareAccelerated="true"\n        android:largeHeap="true"');
  man = man.replace(/<activity/, '<activity\n            android:screenOrientation="sensorLandscape"\n            android:hardwareAccelerated="true"\n            android:resizeableActivity="true"');
  if (!man.includes("WAKE_LOCK")) man = man.replace(/<\/manifest>/, '    <uses-permission android:name="android.permission.WAKE_LOCK" />\n</manifest>');
  // configChanges уже є в шаблоні Capacitor; додамо orientation/screenSize якщо їх немає
  fs.writeFileSync(manPath, man);
  console.log("✓ AndroidManifest.xml оновлено (landscape, hardwareAccelerated, WAKE_LOCK)");
}

// 2) MainActivity.java — immersive + keep screen on + автоплей аудіо
const pkgPath = appId.split(".").join("/");
const dir = path.join(root, "android/app/src/main/java", pkgPath);
fs.mkdirSync(dir, { recursive: true });
fs.writeFileSync(path.join(dir, "MainActivity.java"), `package ${appId};

import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Екран не гасне під час гри
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        // Малюємо під вирізом камери / системними панелями
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        enterImmersive();
        WebView wv = getBridge().getWebView();
        if (wv != null) {
            WebSettings s = wv.getSettings();
            s.setMediaPlaybackRequiresUserGesture(false);
            s.setSupportZoom(false);
            s.setBuiltInZoomControls(false);
            s.setDisplayZoomControls(false);
            s.setTextZoom(100);
            wv.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) enterImmersive();
    }

    @Override
    public void onResume() {
        super.onResume();
        enterImmersive();
    }

    private void enterImmersive() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (c == null) return;
        c.hide(WindowInsetsCompat.Type.statusBars() | WindowInsetsCompat.Type.navigationBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }
}
`);
console.log("✓ MainActivity.java записано");

// 3) styles.xml — контент під вирізом камери (shortEdges)
const stPath = path.join(root, "android/app/src/main/res/values/styles.xml");
if (fs.existsSync(stPath)) {
  let st = fs.readFileSync(stPath, "utf8");
  if (!st.includes("windowLayoutInDisplayCutoutMode")) {
    st = st.replace(/(<style name="AppTheme.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>\n        <item name="android:windowBackground">@android:color/black</item>');
    fs.writeFileSync(stPath, st);
    console.log("✓ styles.xml: display cutout = shortEdges");
  }
}

// 4) Іконка/сплеш (якщо є assets/icon-only.png)
if (fs.existsSync(path.join(root, "assets/icon-only.png"))) {
  try { run("npx @capacitor/assets generate --android --iconBackgroundColor #080812 --splashBackgroundColor #080812"); }
  catch (e) { console.log("(іконки не згенеровано — не критично)"); }
}
console.log("Готово. Далі: npx cap sync android");
